//base by Kemo YT (kemo Bot Inc.)
//YouTube: @kemo_elyoutuber_wa
//Instagram: prexzy.ay
//Telegram: t.me/kemo_elyoutuber1
//GitHub: @Prexzybooster
//WhatsApp: +201222222222
//want more free bot scripts? subscribe to my youtube channel: https://youtube.com/@kemo_elyoutuber_wa

const {
   spawn
} = require('child_process')
const path = require('path')

function start() {
   let args = [path.join(__dirname, 'main.js'), ...process.argv.slice(2)]
   console.log([process.argv[0], ...args].join('\n'))
   let p = spawn(process.argv[0], args, {
         stdio: ['inherit', 'inherit', 'inherit', 'ipc']
      })
      .on('message', data => {
         if (data == 'reset') {
            console.log('Restarting Bot...')
            p.kill()
            start()
            delete p
         }
      })
      .on('exit', code => {
         console.error('Exited with code:', code)
         if (code == '.' || code == 1 || code == 0) start()
      })
}
start()
